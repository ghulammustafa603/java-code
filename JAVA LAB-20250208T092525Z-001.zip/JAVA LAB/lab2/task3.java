public class task3 {
    public static void main(String[] args) {
        String str="The quick brown fox jumps over the lazy dog";
        System.out.println(str.replace("fox","cat"));
    }
}
