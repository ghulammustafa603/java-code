import java.lang.String;
public class task1
{
    public static void main(String str [])
    {
       String str1="Ghulam";
       String str2="Mustafa";
       System.out.println(str1.concat(str2));

    }
}
